<!DOCTYPE html>
<html>
<head>
<style>
h1{
    color:green;
}
.btn{
    top: 0;
	left:0;
	width: 95px;
	height: 100%;
	background: red;
	border-radius: 150px;
	transition: .10s;
}
.btn1{
    color:black;
    padding:30px;
    background:lightgreen;
    float:center;
    font:bold;
}
</style>
</head>
<body>
<h1> <center> YOUR DATA HAS BEEN SUCCESSFULLY STORED IN THE WEBSITE </center> </h1>

<a href="logout.php"><center><button class="btn"> LOGOUT</center></button> 
</body>
</html>


<?php
$sub1=$_POST['s1'];
$sub2=$_POST['s2'];
$sub3=$_POST['s3'];
$sub4=$_POST['s4'];
$sub5=$_POST['s5'];
$sub6=$_POST['s6'];
$sub7=$_POST['s7'];
$sub8=$_POST['s8'];
$mark1=$_POST['m1'];
$mark2=$_POST['m2'];
$mark3=$_POST['m3'];
$mark4=$_POST['m4'];
$mark5=$_POST['m5'];
$mark6=$_POST['m6'];
$mark7=$_POST['m7'];
$mark8=$_POST['m8'];
$usn=$_POST['U'];
$sem=$_POST['s'];



$conn = new mysqli('localhost','root','','test');
 if($conn->connect_error){
    die('connection failed : '.$conn->connect_error);}
    else{
        $stmt=$conn->prepare("insert into subjects(usn,sem,s1,m1,s2,m2,s3,m3,s4,m4,s5,m5,s6,m6,s7,m7,s8,m8)values(?,?,?, ?, ?, ?, ? ,? ,? ,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sisisisisisisisisi",$usn,$sem,$sub1,$mark1 ,$sub2 ,$mark2 ,$sub3 ,$mark3 ,$sub4 ,$mark4,$sub5,$mark5 , $sub6,$mark6 , $sub7 ,$mark7 ,$sub8,$mark8);
        $stmt->execute();
        $stmt->close();
        $conn->close();
    }

?>
