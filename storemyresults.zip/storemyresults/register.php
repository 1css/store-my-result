<!DOCTYPE html>
<html>
<head>
<style>
h1{
    color:red;
}
.btn{
    top: 0;
	left:0;
	width: 95px;
	height: 100%;
	background: #2f2f;
	border-radius: 150px;
	transition: .10s;
}
.btn1{
    color:black;
    padding:30px;
    background:lightgreen;
    float:center;
    font:bold;
}
</style>
</head>
<body>
<h1> <center> USERNAME ALREADY EXISTS!!!!!! </center> </h1>

<a href="logout.php"><center><button class="btn"> LOGOUT</center></button> 
</body>
</html>

<?php
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$username=$_POST['username'];
$password=$_POST['password'];
$cpassword=$_POST['cpassword'];

$conn = new mysqli('localhost','root','','test');
$s = "select * from register_table where username='$username'";
$result = mysqli_query($conn,$s);
$num = mysqli_num_rows($result);
if($num==1){
    
}
else if($conn->connect_error){
    die('connection failed : '.$conn->connect_error);}
    else{
        $stmt=$conn->prepare("insert into register(firstname,lastname,username,password,cpassword)values(?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss",$firstname ,$lastname ,$username ,$password ,$cpassword);
        $stmt->execute();
        $stmt->close();
        $conn->close();
    }

?>
