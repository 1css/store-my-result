<?php

session_start();
session_destroy();

header('location:loginandregister.php');

?>


<input type="button" class="fields" value="SAVE" />

<table border="5" cellpadding="5" cellspacing="5" class="design">

<tr><td colspan="2"align="center" ></td></tr>