create database loginandregister;
use loginandregister;
create table register(id int,firstname varchar(30),lastname varchar(30),user_name varchar(50) primary key, password varchar(50),cpassword varchar(50));





id='register' class='input-group-register'