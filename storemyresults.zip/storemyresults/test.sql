-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2022 at 08:32 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `cpassword` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `firstname`, `lastname`, `username`, `password`, `cpassword`) VALUES
(1, 'kishore', 'l', 'v', 'k123', 'k123'),
(2, 'kishore', 'R', 'ksh', 'k123', 'k123'),
(3, 'kishore', 'r', 'kish', 'k123', 'k123');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `usn` varchar(50) NOT NULL,
  `sem` int(10) NOT NULL,
  `id` int(11) NOT NULL,
  `s1` varchar(50) DEFAULT NULL,
  `s2` varchar(50) DEFAULT NULL,
  `s3` varchar(50) DEFAULT NULL,
  `s4` varchar(50) DEFAULT NULL,
  `s5` varchar(50) DEFAULT NULL,
  `s6` varchar(50) DEFAULT NULL,
  `s7` varchar(50) DEFAULT NULL,
  `s8` varchar(50) DEFAULT NULL,
  `m1` int(30) DEFAULT NULL,
  `m2` int(30) DEFAULT NULL,
  `m3` int(30) DEFAULT NULL,
  `m4` int(30) DEFAULT NULL,
  `m5` int(30) DEFAULT NULL,
  `m6` int(30) DEFAULT NULL,
  `m7` int(30) DEFAULT NULL,
  `m8` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`usn`, `sem`, `id`, `s1`, `s2`, `s3`, `s4`, `s5`, `s6`, `s7`, `s8`, `m1`, `m2`, `m3`, `m4`, `m5`, `m6`, `m7`, `m8`) VALUES
('', 0, 1, '10', '5', '6', '3', '36', '74', '65', '35', 0, 0, 0, 0, 0, 0, 0, 0),
('', 0, 2, '10', '5', '6', '3', '36', '74', '65', '35', 0, 0, 0, 0, 0, 0, 0, 0),
('', 0, 3, '10', '908', '980', '8', '98', '8', '898', '667', 0, 0, 0, 0, 0, 0, 0, 0),
('1au76ef', 0, 4, 'm', 'c', 'a', 's', 't', 'e', 'h', 'c', 1, 12, 23, 56, 3, 7, 5, 9),
('1AY19CS044', 0, 5, 'ss and cd', 'cgv', 'wta', 'cc', 'cns', 'dbms', 'co', 'dsa', 30, 30, 49, 45, 45, 23, 34, 11),
('1AY19CS044', 0, 6, 'ss and cd', 'cgv', 'wta', 'cc', 'cns', 'dbms', 'co', 'dsa', 30, 30, 49, 45, 45, 23, 34, 11),
('1AY19CS044', 0, 7, 'ss and cd', 'cgv', 'wta', 'cc', 'cns', 'dbms', 'co', 'dsa', 30, 30, 49, 45, 45, 23, 34, 11),
('1AY19CS044', 0, 8, 'ss and cd', 'cgv', 'wta', 'cc', 'cns', 'dbms', 'co', 'dsa', 30, 30, 49, 45, 45, 23, 34, 11),
('1AY19CS044', 0, 9, 'ss and cd', 'cgv', 'wta', 'cc', 'cns', 'dbms', 'co', 'dsa', 30, 30, 49, 45, 45, 23, 34, 11),
('1AY19CS044', 0, 10, 'ss and cd', 'cgv', 'wta', 'cc', 'cns', 'dbms', 'co', 'dsa', 30, 30, 49, 45, 45, 23, 34, 11),
('1AY19CS044', 0, 11, 'ss and cd', 'cgv', 'wta', 'cc', 'cns', 'dbms', 'co', 'dsa', 30, 30, 49, 45, 45, 23, 34, 11),
('1AY19CS044', 3, 12, 'ss and cd', '', '', '', '', '', '', '', 65, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 13, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 14, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 15, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 16, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 17, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 18, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 19, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 20, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 21, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 22, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 23, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 3, 24, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 4, 25, 'physics', 'chemistry', 'maths', 'biology', 'english', 'kannada', 'hindi', 'sanskrit', 89, 76, 99, 90, 70, 67, 78, 98),
('1AY19CS044', 4, 26, 'evs', '', '', '', '', '', '', '', 100, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 0, 27, 'cgv', '', '', '', '', '', '', '', 89, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 0, 28, 'cgv', '', '', '', '', '', '', '', 89, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 0, 29, 'cgv', '', '', '', '', '', '', '', 89, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 0, 30, 'cgv', '', '', '', '', '', '', '', 89, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 0, 31, 'ss and cd', '', '', '', '', '', '', '', 67, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 0, 32, 'ss and cd', '', '', '', '', '', '', '', 67, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 0, 33, 'ss and cd', '', '', '', '', '', '', '', 67, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 0, 34, 'ss and cd', '', '', '', '', '', '', '', 67, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 0, 35, 'ss and cd', '', '', '', '', '', '', '', 67, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 4, 36, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 4, 37, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0),
('1AY19CS044', 4, 38, '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
